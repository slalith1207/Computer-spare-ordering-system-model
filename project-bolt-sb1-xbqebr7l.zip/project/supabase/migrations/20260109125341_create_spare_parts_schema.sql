/*
  # Computer Spare Parts E-commerce Platform Schema

  ## Overview
  This migration creates a comprehensive e-commerce platform for computer spare parts with:
  - User profiles and authentication
  - Product catalog with categories and brands
  - Shopping cart and order management
  - Review system with media uploads
  - Credits/rewards system
  - Payment methods support
  - Help center/support tickets
  - Laptop model database for search assistance

  ## New Tables

  ### 1. `user_profiles`
  Extends auth.users with additional profile information
  - `id` (uuid, FK to auth.users)
  - `full_name` (text)
  - `phone` (text)
  - `avatar_url` (text)
  - `address` (jsonb) - stores multiple addresses
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. `brands`
  Computer spare part companies/brands
  - `id` (uuid, PK)
  - `name` (text, unique)
  - `logo_url` (text)
  - `website` (text)
  - `description` (text)
  - `created_at` (timestamptz)

  ### 3. `categories`
  Product categories (RAM, CPU, GPU, etc.)
  - `id` (uuid, PK)
  - `name` (text, unique)
  - `slug` (text, unique)
  - `description` (text)
  - `icon` (text)
  - `created_at` (timestamptz)

  ### 4. `products`
  Computer spare parts catalog
  - `id` (uuid, PK)
  - `name` (text)
  - `description` (text)
  - `category_id` (uuid, FK)
  - `brand_id` (uuid, FK)
  - `price` (numeric)
  - `stock` (integer)
  - `sku` (text, unique)
  - `model_number` (text)
  - `specifications` (jsonb)
  - `images` (text[])
  - `is_active` (boolean)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 5. `laptop_models`
  Database of laptop models for compatibility search
  - `id` (uuid, PK)
  - `brand` (text)
  - `model_name` (text)
  - `model_number` (text)
  - `compatible_parts` (jsonb) - links to product categories
  - `specifications` (jsonb)
  - `created_at` (timestamptz)

  ### 6. `cart_items`
  Shopping cart items
  - `id` (uuid, PK)
  - `user_id` (uuid, FK)
  - `product_id` (uuid, FK)
  - `quantity` (integer)
  - `created_at` (timestamptz)

  ### 7. `orders`
  Customer orders
  - `id` (uuid, PK)
  - `user_id` (uuid, FK)
  - `order_number` (text, unique)
  - `status` (text) - pending, processing, shipped, delivered, cancelled
  - `payment_method` (text) - bank_transfer, cod, upi
  - `payment_status` (text) - pending, completed, failed
  - `subtotal` (numeric)
  - `credits_used` (numeric)
  - `total` (numeric)
  - `shipping_address` (jsonb)
  - `tracking_number` (text)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 8. `order_items`
  Individual items in orders
  - `id` (uuid, PK)
  - `order_id` (uuid, FK)
  - `product_id` (uuid, FK)
  - `quantity` (integer)
  - `price` (numeric)
  - `created_at` (timestamptz)

  ### 9. `reviews`
  Product reviews with ratings and media
  - `id` (uuid, PK)
  - `product_id` (uuid, FK)
  - `user_id` (uuid, FK)
  - `order_id` (uuid, FK)
  - `rating` (integer) - 1-5 stars
  - `title` (text)
  - `comment` (text)
  - `media_urls` (text[]) - images and videos
  - `is_verified_purchase` (boolean)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 10. `user_credits`
  User reward credits
  - `id` (uuid, PK)
  - `user_id` (uuid, FK)
  - `balance` (numeric)
  - `lifetime_earned` (numeric)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 11. `credit_transactions`
  Credit transaction history
  - `id` (uuid, PK)
  - `user_id` (uuid, FK)
  - `order_id` (uuid, FK, nullable)
  - `amount` (numeric)
  - `type` (text) - earned, spent, refunded
  - `description` (text)
  - `created_at` (timestamptz)

  ### 12. `support_tickets`
  Help center tickets
  - `id` (uuid, PK)
  - `user_id` (uuid, FK)
  - `subject` (text)
  - `message` (text)
  - `status` (text) - open, in_progress, resolved, closed
  - `priority` (text) - low, medium, high
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 13. `ticket_messages`
  Messages in support tickets
  - `id` (uuid, PK)
  - `ticket_id` (uuid, FK)
  - `user_id` (uuid, FK, nullable) - null means staff message
  - `message` (text)
  - `attachments` (text[])
  - `created_at` (timestamptz)

  ## Security
  - RLS enabled on all tables
  - Users can only access their own data
  - Public read access for products, categories, brands
  - Authenticated users can create reviews, orders, tickets
*/

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  avatar_url text DEFAULT '',
  address jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create brands table
CREATE TABLE IF NOT EXISTS brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  logo_url text DEFAULT '',
  website text DEFAULT '',
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE brands ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view brands"
  ON brands FOR SELECT
  TO authenticated
  USING (true);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  icon text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view categories"
  ON categories FOR SELECT
  TO authenticated
  USING (true);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  brand_id uuid REFERENCES brands(id) ON DELETE SET NULL,
  price numeric NOT NULL DEFAULT 0,
  stock integer NOT NULL DEFAULT 0,
  sku text UNIQUE NOT NULL,
  model_number text DEFAULT '',
  specifications jsonb DEFAULT '{}'::jsonb,
  images text[] DEFAULT ARRAY[]::text[],
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active products"
  ON products FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Create laptop_models table
CREATE TABLE IF NOT EXISTS laptop_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand text NOT NULL,
  model_name text NOT NULL,
  model_number text NOT NULL,
  compatible_parts jsonb DEFAULT '{}'::jsonb,
  specifications jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE laptop_models ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view laptop models"
  ON laptop_models FOR SELECT
  TO authenticated
  USING (true);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own cart"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cart items"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart items"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cart items"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL NOT NULL,
  order_number text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  payment_method text NOT NULL,
  payment_status text NOT NULL DEFAULT 'pending',
  subtotal numeric NOT NULL DEFAULT 0,
  credits_used numeric NOT NULL DEFAULT 0,
  total numeric NOT NULL DEFAULT 0,
  shipping_address jsonb NOT NULL,
  tracking_number text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  quantity integer NOT NULL,
  price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES orders(id) ON DELETE SET NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title text DEFAULT '',
  comment text DEFAULT '',
  media_urls text[] DEFAULT ARRAY[]::text[],
  is_verified_purchase boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view reviews"
  ON reviews FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create reviews"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reviews"
  ON reviews FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create user_credits table
CREATE TABLE IF NOT EXISTS user_credits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  balance numeric NOT NULL DEFAULT 0,
  lifetime_earned numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_credits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own credits"
  ON user_credits FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create credit_transactions table
CREATE TABLE IF NOT EXISTS credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  order_id uuid REFERENCES orders(id) ON DELETE SET NULL,
  amount numeric NOT NULL,
  type text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own transactions"
  ON credit_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create support_tickets table
CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  priority text NOT NULL DEFAULT 'medium',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tickets"
  ON support_tickets FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create tickets"
  ON support_tickets FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tickets"
  ON support_tickets FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create ticket_messages table
CREATE TABLE IF NOT EXISTS ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid REFERENCES support_tickets(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  message text NOT NULL,
  attachments text[] DEFAULT ARRAY[]::text[],
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ticket_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages from own tickets"
  ON ticket_messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM support_tickets
      WHERE support_tickets.id = ticket_messages.ticket_id
      AND support_tickets.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create messages in own tickets"
  ON ticket_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM support_tickets
      WHERE support_tickets.id = ticket_messages.ticket_id
      AND support_tickets.user_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand_id);
CREATE INDEX IF NOT EXISTS idx_products_model ON products(model_number);
CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_laptop_models_number ON laptop_models(model_number);
CREATE INDEX IF NOT EXISTS idx_support_tickets_user ON support_tickets(user_id);
