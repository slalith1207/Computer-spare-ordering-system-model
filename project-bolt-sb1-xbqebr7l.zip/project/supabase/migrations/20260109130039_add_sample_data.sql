/*
  # Add Sample Data for E-commerce Platform

  ## Overview
  This migration adds sample data to populate the platform with:
  - Computer spare part categories
  - Popular brands
  - Sample products
  - Laptop models for compatibility search

  ## Data Added

  ### Categories
  - RAM
  - CPU/Processors
  - GPU/Graphics Cards
  - Hard Drives/SSD
  - Motherboards
  - Power Supply
  - Cooling Systems
  - Keyboards
  - Mouse
  - Monitors

  ### Brands
  - Intel, AMD, NVIDIA, Kingston, Samsung, Corsair, etc.

  ### Products
  - Various computer parts with realistic pricing and specifications

  ### Laptop Models
  - Popular laptop models from Dell, HP, Lenovo, ASUS for compatibility search
*/

-- Insert Categories
INSERT INTO categories (name, slug, description, icon) VALUES
('RAM', 'ram', 'Memory modules for laptops and desktops', 'memory-stick'),
('CPU', 'cpu', 'Processors and CPUs', 'cpu'),
('GPU', 'gpu', 'Graphics cards and video cards', 'monitor'),
('Storage', 'storage', 'Hard drives, SSDs, and storage devices', 'hard-drive'),
('Motherboard', 'motherboard', 'Motherboards and mainboards', 'grid'),
('Power Supply', 'power-supply', 'Power supply units', 'zap'),
('Cooling', 'cooling', 'Cooling systems and fans', 'wind'),
('Keyboard', 'keyboard', 'Keyboards and input devices', 'keyboard'),
('Mouse', 'mouse', 'Mouse and pointing devices', 'mouse'),
('Monitor', 'monitor', 'Displays and monitors', 'monitor')
ON CONFLICT (name) DO NOTHING;

-- Insert Brands
INSERT INTO brands (name, logo_url, website, description) VALUES
('Intel', '', 'https://www.intel.com', 'Leading processor manufacturer'),
('AMD', '', 'https://www.amd.com', 'Advanced Micro Devices'),
('NVIDIA', '', 'https://www.nvidia.com', 'Graphics card manufacturer'),
('Kingston', '', 'https://www.kingston.com', 'Memory and storage solutions'),
('Samsung', '', 'https://www.samsung.com', 'Electronics and storage'),
('Corsair', '', 'https://www.corsair.com', 'Gaming peripherals and components'),
('Seagate', '', 'https://www.seagate.com', 'Storage solutions'),
('Western Digital', '', 'https://www.westerndigital.com', 'Storage manufacturer'),
('ASUS', '', 'https://www.asus.com', 'Computer hardware and electronics'),
('Logitech', '', 'https://www.logitech.com', 'Peripherals and accessories'),
('Dell', '', 'https://www.dell.com', 'Computer manufacturer'),
('HP', '', 'https://www.hp.com', 'Technology company'),
('Crucial', '', 'https://www.crucial.com', 'Memory and storage'),
('MSI', '', 'https://www.msi.com', 'Gaming hardware')
ON CONFLICT (name) DO NOTHING;

-- Insert Sample Products
INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Kingston HyperX 16GB DDR4 3200MHz',
  'High-performance gaming memory with aggressive styling and heat spreader',
  (SELECT id FROM categories WHERE slug = 'ram' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Kingston' LIMIT 1),
  4500,
  50,
  'RAM-KHX-16GB-001',
  'HX432C16FB3/16',
  '{"capacity": "16GB", "type": "DDR4", "speed": "3200MHz", "cas_latency": "CL16"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'RAM-KHX-16GB-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Corsair Vengeance 32GB DDR4 3600MHz',
  'Premium performance DDR4 memory for gaming and content creation',
  (SELECT id FROM categories WHERE slug = 'ram' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Corsair' LIMIT 1),
  8999,
  30,
  'RAM-COR-32GB-001',
  'CMK32GX4M2D3600C18',
  '{"capacity": "32GB", "type": "DDR4", "speed": "3600MHz", "modules": "2x16GB"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'RAM-COR-32GB-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Intel Core i7-12700K',
  '12th Gen Intel Core processor with 12 cores and 20 threads',
  (SELECT id FROM categories WHERE slug = 'cpu' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Intel' LIMIT 1),
  32999,
  25,
  'CPU-INT-I7-001',
  'i7-12700K',
  '{"cores": "12", "threads": "20", "base_clock": "3.6GHz", "boost_clock": "5.0GHz"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2582933/pexels-photo-2582933.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'CPU-INT-I7-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'AMD Ryzen 9 5900X',
  '12-core, 24-thread processor for gaming and productivity',
  (SELECT id FROM categories WHERE slug = 'cpu' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'AMD' LIMIT 1),
  35999,
  20,
  'CPU-AMD-R9-001',
  'Ryzen 9 5900X',
  '{"cores": "12", "threads": "24", "base_clock": "3.7GHz", "boost_clock": "4.8GHz"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2582933/pexels-photo-2582933.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'CPU-AMD-R9-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'NVIDIA RTX 4070 Ti 12GB',
  'High-performance graphics card for gaming and content creation',
  (SELECT id FROM categories WHERE slug = 'gpu' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'NVIDIA' LIMIT 1),
  79999,
  15,
  'GPU-NV-4070TI-001',
  'RTX 4070 Ti',
  '{"memory": "12GB GDDR6X", "cuda_cores": "7680", "boost_clock": "2610MHz"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/6853495/pexels-photo-6853495.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'GPU-NV-4070TI-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Samsung 980 PRO 1TB NVMe SSD',
  'PCIe 4.0 NVMe M.2 SSD with exceptional speed',
  (SELECT id FROM categories WHERE slug = 'storage' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Samsung' LIMIT 1),
  9999,
  40,
  'SSD-SAM-1TB-001',
  '980 PRO 1TB',
  '{"capacity": "1TB", "interface": "PCIe 4.0", "read_speed": "7000MB/s", "write_speed": "5000MB/s"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2582934/pexels-photo-2582934.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SSD-SAM-1TB-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Crucial MX500 2TB SATA SSD',
  'Reliable 2.5-inch SATA SSD with great value',
  (SELECT id FROM categories WHERE slug = 'storage' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Crucial' LIMIT 1),
  13999,
  35,
  'SSD-CRU-2TB-001',
  'MX500 2TB',
  '{"capacity": "2TB", "interface": "SATA III", "read_speed": "560MB/s", "write_speed": "510MB/s"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2582934/pexels-photo-2582934.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'SSD-CRU-2TB-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Logitech G502 HERO Gaming Mouse',
  'High-performance gaming mouse with 25K DPI sensor',
  (SELECT id FROM categories WHERE slug = 'mouse' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Logitech' LIMIT 1),
  4999,
  60,
  'MSE-LOG-G502-001',
  'G502 HERO',
  '{"dpi": "25600", "buttons": "11", "weight": "121g", "rgb": "Yes"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/2115257/pexels-photo-2115257.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'MSE-LOG-G502-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'Corsair K70 RGB Mechanical Keyboard',
  'Premium mechanical gaming keyboard with Cherry MX switches',
  (SELECT id FROM categories WHERE slug = 'keyboard' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'Corsair' LIMIT 1),
  12999,
  25,
  'KBD-COR-K70-001',
  'K70 RGB MK.2',
  '{"switches": "Cherry MX Red", "backlight": "RGB", "layout": "Full Size", "connection": "Wired"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'KBD-COR-K70-001');

INSERT INTO products (name, description, category_id, brand_id, price, stock, sku, model_number, specifications, images, is_active)
SELECT
  'ASUS TUF Gaming VG27AQ 27" Monitor',
  '1440p 165Hz IPS gaming monitor with G-Sync',
  (SELECT id FROM categories WHERE slug = 'monitor' LIMIT 1),
  (SELECT id FROM brands WHERE name = 'ASUS' LIMIT 1),
  28999,
  20,
  'MON-ASU-27-001',
  'VG27AQ',
  '{"size": "27 inches", "resolution": "2560x1440", "refresh_rate": "165Hz", "panel": "IPS"}'::jsonb,
  ARRAY['https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg'],
  true
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku = 'MON-ASU-27-001');

-- Insert Sample Laptop Models
INSERT INTO laptop_models (brand, model_name, model_number, compatible_parts, specifications)
SELECT
  'Dell',
  'Inspiron 15 3000',
  '15-3511',
  '{}'::jsonb,
  '{"processor": "Intel Core i5", "ram": "8GB DDR4", "storage": "256GB SSD"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM laptop_models WHERE model_number = '15-3511');

INSERT INTO laptop_models (brand, model_name, model_number, compatible_parts, specifications)
SELECT
  'HP',
  'Pavilion 15',
  '15-eg0xxx',
  '{}'::jsonb,
  '{"processor": "Intel Core i7", "ram": "16GB DDR4", "storage": "512GB SSD"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM laptop_models WHERE model_number = '15-eg0xxx');

INSERT INTO laptop_models (brand, model_name, model_number, compatible_parts, specifications)
SELECT
  'Lenovo',
  'ThinkPad E15',
  'E15 Gen 3',
  '{}'::jsonb,
  '{"processor": "AMD Ryzen 5", "ram": "8GB DDR4", "storage": "256GB SSD"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM laptop_models WHERE model_number = 'E15 Gen 3');

INSERT INTO laptop_models (brand, model_name, model_number, compatible_parts, specifications)
SELECT
  'ASUS',
  'VivoBook 15',
  'X515EA',
  '{}'::jsonb,
  '{"processor": "Intel Core i3", "ram": "4GB DDR4", "storage": "1TB HDD"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM laptop_models WHERE model_number = 'X515EA');

INSERT INTO laptop_models (brand, model_name, model_number, compatible_parts, specifications)
SELECT
  'Dell',
  'XPS 13',
  'XPS 13 9310',
  '{}'::jsonb,
  '{"processor": "Intel Core i7", "ram": "16GB LPDDR4x", "storage": "512GB SSD"}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM laptop_models WHERE model_number = 'XPS 13 9310');
