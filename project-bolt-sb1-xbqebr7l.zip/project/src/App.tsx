import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginForm } from './components/Auth/LoginForm';
import { RegisterForm } from './components/Auth/RegisterForm';
import { Header } from './components/Layout/Header';
import { ProductList } from './components/Products/ProductList';
import { ProductDetails } from './components/Products/ProductDetails';
import { CartPage } from './components/Cart/CartPage';
import { CheckoutPage } from './components/Checkout/CheckoutPage';
import { ProfilePage } from './components/Profile/ProfilePage';
import { OrdersPage } from './components/Orders/OrdersPage';
import { SupportPage } from './components/Support/SupportPage';
import { SearchAssistant } from './components/Search/SearchAssistant';
import { ReviewModal } from './components/Reviews/ReviewModal';
import { supabase } from './lib/supabase';

function AppContent() {
  const { user, loading } = useAuth();
  const [showLogin, setShowLogin] = useState(true);
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [cartCount, setCartCount] = useState(0);
  const [reviewProduct, setReviewProduct] = useState<{ productId: string; orderId: string } | null>(null);

  useEffect(() => {
    if (user) {
      loadCartCount();
    }
  }, [user, currentPage]);

  const loadCartCount = async () => {
    const { data } = await supabase
      .from('cart_items')
      .select('quantity')
      .eq('user_id', user?.id);

    const total = data?.reduce((sum, item) => sum + item.quantity, 0) || 0;
    setCartCount(total);
  };

  const handleAddToCart = async (productId: string) => {
    try {
      const { data: existing } = await supabase
        .from('cart_items')
        .select('*')
        .eq('user_id', user?.id)
        .eq('product_id', productId)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('cart_items')
          .update({ quantity: existing.quantity + 1 })
          .eq('id', existing.id);
      } else {
        await supabase.from('cart_items').insert({
          user_id: user?.id,
          product_id: productId,
          quantity: 1,
        });
      }

      loadCartCount();
      alert('Product added to cart!');
    } catch (error) {
      console.error('Failed to add to cart:', error);
      alert('Failed to add to cart');
    }
  };

  const handleCheckoutComplete = () => {
    setCurrentPage('orders');
    loadCartCount();
  };

  const handleReview = (productId: string, orderId: string) => {
    setReviewProduct({ productId, orderId });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center p-4">
        {showLogin ? (
          <LoginForm onToggle={() => setShowLogin(false)} />
        ) : (
          <RegisterForm onToggle={() => setShowLogin(true)} />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header onNavigate={setCurrentPage} cartCount={cartCount} currentPage={currentPage} />

      <main>
        {currentPage === 'home' && !selectedProductId && (
          <ProductList
            onAddToCart={handleAddToCart}
            onViewDetails={setSelectedProductId}
          />
        )}

        {currentPage === 'home' && selectedProductId && (
          <ProductDetails
            productId={selectedProductId}
            onBack={() => setSelectedProductId(null)}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentPage === 'cart' && (
          <CartPage onCheckout={() => setCurrentPage('checkout')} />
        )}

        {currentPage === 'checkout' && (
          <CheckoutPage
            onBack={() => setCurrentPage('cart')}
            onComplete={handleCheckoutComplete}
          />
        )}

        {currentPage === 'profile' && <ProfilePage />}

        {currentPage === 'orders' && <OrdersPage onReview={handleReview} />}

        {currentPage === 'support' && <SupportPage />}

        {currentPage === 'search' && (
          <SearchAssistant
            onSelectProduct={(id) => {
              setSelectedProductId(id);
              setCurrentPage('home');
            }}
          />
        )}
      </main>

      {reviewProduct && (
        <ReviewModal
          productId={reviewProduct.productId}
          orderId={reviewProduct.orderId}
          onClose={() => setReviewProduct(null)}
          onSubmit={() => {
            setReviewProduct(null);
            alert('Review submitted successfully!');
          }}
        />
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
