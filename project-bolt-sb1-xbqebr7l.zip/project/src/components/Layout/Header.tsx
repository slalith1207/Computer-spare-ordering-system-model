import { ShoppingCart, User, Search, HelpCircle, LogOut, Package, Cpu } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface HeaderProps {
  onNavigate: (page: string) => void;
  cartCount: number;
  currentPage: string;
}

export function Header({ onNavigate, cartCount, currentPage }: HeaderProps) {
  const { user, signOut } = useAuth();

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center space-x-2 text-2xl font-bold text-blue-600 hover:text-blue-700 transition"
          >
            <Cpu className="w-8 h-8" />
            <span>TechParts Pro</span>
          </button>

          <nav className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => onNavigate('home')}
              className={`hover:text-blue-600 transition font-medium ${
                currentPage === 'home' ? 'text-blue-600' : 'text-gray-700'
              }`}
            >
              Products
            </button>
            <button
              onClick={() => onNavigate('orders')}
              className={`hover:text-blue-600 transition font-medium ${
                currentPage === 'orders' ? 'text-blue-600' : 'text-gray-700'
              }`}
            >
              My Orders
            </button>
            <button
              onClick={() => onNavigate('support')}
              className={`hover:text-blue-600 transition font-medium ${
                currentPage === 'support' ? 'text-blue-600' : 'text-gray-700'
              }`}
            >
              Support
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => onNavigate('search')}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="AI Search Assistant"
            >
              <Search className="w-5 h-5 text-gray-700" />
            </button>

            <button
              onClick={() => onNavigate('cart')}
              className="relative p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onNavigate('profile')}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Profile"
            >
              <User className="w-5 h-5 text-gray-700" />
            </button>

            <button
              onClick={signOut}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Sign Out"
            >
              <LogOut className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
