import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Search, Cpu, HardDrive, Zap, ArrowRight } from 'lucide-react';

interface SearchAssistantProps {
  onSelectProduct: (productId: string) => void;
}

export function SearchAssistant({ onSelectProduct }: SearchAssistantProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [laptopModels, setLaptopModels] = useState<any[]>([]);
  const [selectedModel, setSelectedModel] = useState<any>(null);
  const [compatibleProducts, setCompatibleProducts] = useState<any[]>([]);
  const [allProducts, setAllProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadLaptopModels();
    loadProducts();
  }, []);

  const loadLaptopModels = async () => {
    const { data } = await supabase.from('laptop_models').select('*');
    setLaptopModels(data || []);
  };

  const loadProducts = async () => {
    const { data } = await supabase.from('products').select('*').eq('is_active', true);
    setAllProducts(data || []);
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setLoading(true);

    const { data } = await supabase
      .from('laptop_models')
      .select('*')
      .or(`model_name.ilike.%${searchQuery}%,model_number.ilike.%${searchQuery}%,brand.ilike.%${searchQuery}%`);

    if (data && data.length > 0) {
      setSelectedModel(data[0]);
      loadCompatibleProducts(data[0]);
    } else {
      setSelectedModel(null);
      setCompatibleProducts([]);
    }

    setLoading(false);
  };

  const loadCompatibleProducts = async (model: any) => {
    const compatible = allProducts.filter((product) => {
      if (model.compatible_parts && model.compatible_parts[product.category_id]) {
        return true;
      }
      return product.model_number.toLowerCase().includes(model.model_number.toLowerCase());
    });

    setCompatibleProducts(compatible);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
          <Search className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">AI Search Assistant</h1>
        <p className="text-gray-600">
          Find compatible parts for your laptop by model name or number
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex space-x-3">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Enter laptop model (e.g., Dell Inspiron 15, HP Pavilion...)"
            className="flex-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 text-lg"
          />
          <button
            onClick={handleSearch}
            disabled={loading}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition disabled:bg-blue-300 flex items-center space-x-2"
          >
            <Search className="w-5 h-5" />
            <span>Search</span>
          </button>
        </div>
      </div>

      {loading && (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
        </div>
      )}

      {selectedModel && !loading && (
        <div className="bg-gradient-to-br from-blue-50 to-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
              <Cpu className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-800 mb-1">
                {selectedModel.brand} {selectedModel.model_name}
              </h2>
              <p className="text-gray-600 mb-3">Model Number: {selectedModel.model_number}</p>

              {selectedModel.specifications && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                  {Object.entries(selectedModel.specifications).map(([key, value]) => (
                    <div key={key} className="bg-white p-2 rounded">
                      <span className="text-gray-500 capitalize">{key}: </span>
                      <span className="font-medium">{String(value)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {compatibleProducts.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Compatible Parts ({compatibleProducts.length})
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {compatibleProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition"
              >
                <div className="flex items-start space-x-4">
                  <img
                    src={
                      product.images[0] ||
                      'https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg?auto=compress&cs=tinysrgb&w=200'
                    }
                    alt={product.name}
                    className="w-20 h-20 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">{product.name}</h3>
                    <p className="text-sm text-gray-500 mb-2">{product.model_number}</p>
                    <p className="text-lg font-bold text-blue-600 mb-2">
                      ₹{product.price.toLocaleString()}
                    </p>
                    <button
                      onClick={() => onSelectProduct(product.id)}
                      className="flex items-center space-x-1 text-sm text-blue-600 hover:text-blue-700 font-medium"
                    >
                      <span>View Details</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedModel && compatibleProducts.length === 0 && !loading && (
        <div className="text-center py-12">
          <HardDrive className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">No compatible parts found for this model</p>
          <p className="text-gray-400 text-sm">Try browsing our catalog for general parts</p>
        </div>
      )}

      <div className="mt-12 bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Quick Tips:</h3>
        <ul className="space-y-2 text-gray-600">
          <li className="flex items-start space-x-2">
            <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <span>Search by laptop brand and model (e.g., "Dell XPS 15")</span>
          </li>
          <li className="flex items-start space-x-2">
            <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <span>Use model numbers for precise results (e.g., "15-da0xxx")</span>
          </li>
          <li className="flex items-start space-x-2">
            <Zap className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <span>Check specifications to ensure compatibility</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
