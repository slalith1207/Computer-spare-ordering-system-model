import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { CreditCard, Banknote, Smartphone, ArrowLeft } from 'lucide-react';

interface CheckoutPageProps {
  onBack: () => void;
  onComplete: () => void;
}

export function CheckoutPage({ onBack, onComplete }: CheckoutPageProps) {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'bank' | 'cod' | 'upi'>('upi');
  const [useCredits, setUseCredits] = useState(false);
  const [userCredits, setUserCredits] = useState(0);
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState({
    street: '',
    city: '',
    state: '',
    pincode: '',
    phone: '',
  });

  useEffect(() => {
    if (user) {
      loadCheckoutData();
    }
  }, [user]);

  const loadCheckoutData = async () => {
    const [cartData, creditsData, profileData] = await Promise.all([
      supabase.from('cart_items').select('*, products(*)').eq('user_id', user?.id),
      supabase.from('user_credits').select('balance').eq('user_id', user?.id).maybeSingle(),
      supabase.from('user_profiles').select('*').eq('id', user?.id).maybeSingle(),
    ]);

    setCartItems(cartData.data || []);
    setUserCredits(creditsData.data?.balance || 0);

    if (profileData.data?.address && profileData.data.address.length > 0) {
      setAddress(profileData.data.address[0]);
    }
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.products.price * item.quantity, 0);
  const creditsToUse = useCredits ? Math.min(userCredits, subtotal) : 0;
  const total = subtotal - creditsToUse;

  const handlePlaceOrder = async () => {
    setLoading(true);

    try {
      const orderNumber = `ORD-${Date.now()}`;

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user?.id,
          order_number: orderNumber,
          status: 'pending',
          payment_method: paymentMethod,
          payment_status: paymentMethod === 'cod' ? 'pending' : 'completed',
          subtotal,
          credits_used: creditsToUse,
          total,
          shipping_address: address,
        })
        .select()
        .single();

      if (orderError) throw orderError;

      const orderItems = cartItems.map((item) => ({
        order_id: order.id,
        product_id: item.product_id,
        quantity: item.quantity,
        price: item.products.price,
      }));

      await supabase.from('order_items').insert(orderItems);

      if (useCredits && creditsToUse > 0) {
        await supabase.rpc('update_user_credits', {
          p_user_id: user?.id,
          p_amount: -creditsToUse,
        }).catch(() => {
          supabase
            .from('user_credits')
            .update({ balance: userCredits - creditsToUse })
            .eq('user_id', user?.id);
        });

        await supabase.from('credit_transactions').insert({
          user_id: user?.id,
          order_id: order.id,
          amount: -creditsToUse,
          type: 'spent',
          description: `Used for order ${orderNumber}`,
        });
      }

      const creditsEarned = Math.floor(total * 0.02);
      if (creditsEarned > 0) {
        await supabase.rpc('update_user_credits', {
          p_user_id: user?.id,
          p_amount: creditsEarned,
        }).catch(() => {
          supabase
            .from('user_credits')
            .update({
              balance: userCredits - creditsToUse + creditsEarned,
              lifetime_earned: creditsEarned,
            })
            .eq('user_id', user?.id);
        });

        await supabase.from('credit_transactions').insert({
          user_id: user?.id,
          order_id: order.id,
          amount: creditsEarned,
          type: 'earned',
          description: `Earned from order ${orderNumber} (2% cashback)`,
        });
      }

      await supabase.from('cart_items').delete().eq('user_id', user?.id);

      onComplete();
    } catch (error) {
      console.error('Order placement failed:', error);
      alert('Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Cart</span>
      </button>

      <h1 className="text-3xl font-bold text-gray-800 mb-6">Checkout</h1>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Shipping Address</h2>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Street Address"
                value={address.street}
                onChange={(e) => setAddress({ ...address, street: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="City"
                  value={address.city}
                  onChange={(e) => setAddress({ ...address, city: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
                <input
                  type="text"
                  placeholder="State"
                  value={address.state}
                  onChange={(e) => setAddress({ ...address, state: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Pincode"
                  value={address.pincode}
                  onChange={(e) => setAddress({ ...address, pincode: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
                <input
                  type="tel"
                  placeholder="Phone"
                  value={address.phone}
                  onChange={(e) => setAddress({ ...address, phone: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Payment Method</h2>
            <div className="space-y-3">
              <label className="flex items-center space-x-3 p-3 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition">
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'upi'}
                  onChange={() => setPaymentMethod('upi')}
                  className="w-5 h-5"
                />
                <Smartphone className="w-5 h-5 text-gray-600" />
                <span className="font-medium">UPI Payment</span>
              </label>

              <label className="flex items-center space-x-3 p-3 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition">
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'bank'}
                  onChange={() => setPaymentMethod('bank')}
                  className="w-5 h-5"
                />
                <CreditCard className="w-5 h-5 text-gray-600" />
                <span className="font-medium">Bank Transfer</span>
              </label>

              <label className="flex items-center space-x-3 p-3 border-2 rounded-lg cursor-pointer hover:bg-gray-50 transition">
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'cod'}
                  onChange={() => setPaymentMethod('cod')}
                  className="w-5 h-5"
                />
                <Banknote className="w-5 h-5 text-gray-600" />
                <span className="font-medium">Cash on Delivery</span>
              </label>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

            <div className="space-y-3 mb-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-gray-600">
                    {item.products.name} x{item.quantity}
                  </span>
                  <span className="font-medium">
                    ₹{(item.products.price * item.quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t pt-3 space-y-2 mb-4">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>₹{subtotal.toLocaleString()}</span>
              </div>

              {userCredits > 0 && (
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-sm text-gray-600">Use Credits (₹{userCredits})</span>
                  <input
                    type="checkbox"
                    checked={useCredits}
                    onChange={(e) => setUseCredits(e.target.checked)}
                    className="w-5 h-5"
                  />
                </label>
              )}

              {useCredits && creditsToUse > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Credits Applied</span>
                  <span>-₹{creditsToUse.toLocaleString()}</span>
                </div>
              )}

              <div className="border-t pt-2 flex justify-between text-lg font-bold">
                <span>Total</span>
                <span className="text-blue-600">₹{total.toLocaleString()}</span>
              </div>

              <p className="text-xs text-green-600">
                You'll earn ₹{Math.floor(total * 0.02)} credits with this order!
              </p>
            </div>

            <button
              onClick={handlePlaceOrder}
              disabled={loading || !address.street || !address.city}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-medium disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              {loading ? 'Processing...' : 'Place Order'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
