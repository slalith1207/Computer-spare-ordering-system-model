import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Package, Truck, CheckCircle, Clock, Star } from 'lucide-react';

interface OrdersPageProps {
  onReview: (productId: string, orderId: string) => void;
}

export function OrdersPage({ onReview }: OrdersPageProps) {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadOrders();
    }
  }, [user]);

  const loadOrders = async () => {
    const { data } = await supabase
      .from('orders')
      .select('*, order_items(*, products(*))')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false });

    setOrders(data || []);
    setLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'processing':
        return <Package className="w-5 h-5 text-blue-500" />;
      case 'shipped':
        return <Truck className="w-5 h-5 text-orange-500" />;
      case 'delivered':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-orange-100 text-orange-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <Package className="w-24 h-24 text-gray-300 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">No orders yet</h2>
        <p className="text-gray-500">Start shopping to see your orders here!</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">My Orders</h1>

      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 bg-gray-50 border-b flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-800">Order #{order.order_number}</p>
                <p className="text-sm text-gray-500">
                  {new Date(order.created_at).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(
                    order.status
                  )}`}
                >
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </span>
                {getStatusIcon(order.status)}
              </div>
            </div>

            <div className="p-4">
              <div className="space-y-3 mb-4">
                {order.order_items.map((item: any) => (
                  <div key={item.id} className="flex items-center space-x-4">
                    <img
                      src={
                        item.products.images[0] ||
                        'https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg?auto=compress&cs=tinysrgb&w=200'
                      }
                      alt={item.products.name}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">{item.products.name}</p>
                      <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                      <p className="text-sm font-medium text-blue-600">
                        ₹{item.price.toLocaleString()}
                      </p>
                    </div>
                    {order.status === 'delivered' && (
                      <button
                        onClick={() => onReview(item.product_id, order.id)}
                        className="flex items-center space-x-1 px-3 py-1 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                      >
                        <Star className="w-4 h-4" />
                        <span>Review</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <div className="border-t pt-3 flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-600">Payment: {order.payment_method.toUpperCase()}</p>
                  {order.tracking_number && (
                    <p className="text-sm text-gray-600">Tracking: {order.tracking_number}</p>
                  )}
                </div>
                <div className="text-right">
                  {order.credits_used > 0 && (
                    <p className="text-sm text-green-600">Credits Used: ₹{order.credits_used}</p>
                  )}
                  <p className="text-lg font-bold text-gray-800">
                    Total: ₹{order.total.toLocaleString()}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedOrder(selectedOrder === order.id ? null : order.id)}
                className="mt-3 text-sm text-blue-600 hover:underline"
              >
                {selectedOrder === order.id ? 'Hide' : 'View'} Shipping Address
              </button>

              {selectedOrder === order.id && (
                <div className="mt-3 p-3 bg-gray-50 rounded-lg text-sm">
                  <p className="font-medium mb-1">Shipping Address:</p>
                  <p>{order.shipping_address.street}</p>
                  <p>
                    {order.shipping_address.city}, {order.shipping_address.state} -{' '}
                    {order.shipping_address.pincode}
                  </p>
                  <p>Phone: {order.shipping_address.phone}</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
