import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { ArrowLeft, ShoppingCart, Star, Package, Shield, Truck } from 'lucide-react';

interface ProductDetailsProps {
  productId: string;
  onBack: () => void;
  onAddToCart: (productId: string) => void;
}

export function ProductDetails({ productId, onBack, onAddToCart }: ProductDetailsProps) {
  const [product, setProduct] = useState<any>(null);
  const [reviews, setReviews] = useState<any[]>([]);
  const [brand, setBrand] = useState<any>(null);
  const [category, setCategory] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);

  useEffect(() => {
    loadProductDetails();
  }, [productId]);

  const loadProductDetails = async () => {
    const [productData, reviewsData] = await Promise.all([
      supabase.from('products').select('*').eq('id', productId).single(),
      supabase.from('reviews').select('*, user_profiles(full_name)').eq('product_id', productId),
    ]);

    if (productData.data) {
      setProduct(productData.data);

      if (productData.data.brand_id) {
        const { data: brandData } = await supabase
          .from('brands')
          .select('*')
          .eq('id', productData.data.brand_id)
          .single();
        setBrand(brandData);
      }

      if (productData.data.category_id) {
        const { data: categoryData } = await supabase
          .from('categories')
          .select('*')
          .eq('id', productData.data.category_id)
          .single();
        setCategory(categoryData);
      }
    }

    setReviews(reviewsData.data || []);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  if (!product) {
    return <div className="text-center py-12">Product not found</div>;
  }

  const images = product.images.length > 0
    ? product.images
    : ['https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg?auto=compress&cs=tinysrgb&w=800'];

  const avgRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Products</span>
      </button>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <div>
          <div className="bg-gray-100 rounded-lg overflow-hidden mb-4">
            <img
              src={images[selectedImage]}
              alt={product.name}
              className="w-full h-96 object-cover"
            />
          </div>
          {images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {images.map((img: string, idx: number) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`border-2 rounded-lg overflow-hidden ${
                    selectedImage === idx ? 'border-blue-600' : 'border-gray-200'
                  }`}
                >
                  <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-20 object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          {category && (
            <span className="inline-block bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full mb-3">
              {category.name}
            </span>
          )}
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{product.name}</h1>
          {brand && <p className="text-gray-600 mb-3">by {brand.name}</p>}

          <div className="flex items-center mb-4">
            <div className="flex items-center">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-5 h-5 ${
                    star <= avgRating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <span className="ml-2 text-gray-600">
              {avgRating.toFixed(1)} ({reviews.length} reviews)
            </span>
          </div>

          <div className="mb-6">
            <p className="text-4xl font-bold text-blue-600 mb-2">
              ₹{product.price.toLocaleString()}
            </p>
            <p className="text-sm text-gray-600">Model: {product.model_number}</p>
            <p className="text-sm text-gray-600">SKU: {product.sku}</p>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            <div className="flex items-center space-x-2 text-green-600">
              <Package className="w-5 h-5" />
              <span className="text-sm font-medium">{product.stock} in stock</span>
            </div>
            <div className="flex items-center space-x-2 text-blue-600">
              <Shield className="w-5 h-5" />
              <span className="text-sm font-medium">Genuine Product</span>
            </div>
            <div className="flex items-center space-x-2 text-orange-600">
              <Truck className="w-5 h-5" />
              <span className="text-sm font-medium">Fast Delivery</span>
            </div>
          </div>

          <button
            onClick={() => onAddToCart(product.id)}
            disabled={product.stock === 0}
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center space-x-2 text-lg font-medium"
          >
            <ShoppingCart className="w-6 h-6" />
            <span>{product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}</span>
          </button>

          <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-green-800">
              Earn <span className="font-bold">₹{Math.floor(product.price * 0.02)}</span> credits
              with this purchase!
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Description</h2>
        <p className="text-gray-600 leading-relaxed">{product.description}</p>

        {product.specifications && Object.keys(product.specifications).length > 0 && (
          <div className="mt-6">
            <h3 className="text-xl font-bold text-gray-800 mb-3">Specifications</h3>
            <div className="grid md:grid-cols-2 gap-3">
              {Object.entries(product.specifications).map(([key, value]) => (
                <div key={key} className="flex justify-between p-3 bg-gray-50 rounded">
                  <span className="font-medium text-gray-700 capitalize">{key}</span>
                  <span className="text-gray-600">{String(value)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          Customer Reviews ({reviews.length})
        </h2>

        {reviews.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No reviews yet. Be the first to review!</p>
        ) : (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="border-b pb-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-800">{review.user_profiles?.full_name || 'Anonymous'}</p>
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= review.rating
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">
                      {new Date(review.created_at).toLocaleDateString()}
                    </p>
                    {review.is_verified_purchase && (
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                        Verified Purchase
                      </span>
                    )}
                  </div>
                </div>
                {review.title && <h4 className="font-semibold text-gray-800 mb-1">{review.title}</h4>}
                <p className="text-gray-600">{review.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
