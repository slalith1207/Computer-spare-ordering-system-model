export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          full_name: string;
          phone: string;
          avatar_url: string;
          address: any;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name?: string;
          phone?: string;
          avatar_url?: string;
          address?: any;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          phone?: string;
          avatar_url?: string;
          address?: any;
          created_at?: string;
          updated_at?: string;
        };
      };
      brands: {
        Row: {
          id: string;
          name: string;
          logo_url: string;
          website: string;
          description: string;
          created_at: string;
        };
      };
      categories: {
        Row: {
          id: string;
          name: string;
          slug: string;
          description: string;
          icon: string;
          created_at: string;
        };
      };
      products: {
        Row: {
          id: string;
          name: string;
          description: string;
          category_id: string | null;
          brand_id: string | null;
          price: number;
          stock: number;
          sku: string;
          model_number: string;
          specifications: any;
          images: string[];
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
      };
      cart_items: {
        Row: {
          id: string;
          user_id: string;
          product_id: string;
          quantity: number;
          created_at: string;
        };
      };
      orders: {
        Row: {
          id: string;
          user_id: string;
          order_number: string;
          status: string;
          payment_method: string;
          payment_status: string;
          subtotal: number;
          credits_used: number;
          total: number;
          shipping_address: any;
          tracking_number: string;
          created_at: string;
          updated_at: string;
        };
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string | null;
          quantity: number;
          price: number;
          created_at: string;
        };
      };
      reviews: {
        Row: {
          id: string;
          product_id: string;
          user_id: string;
          order_id: string | null;
          rating: number;
          title: string;
          comment: string;
          media_urls: string[];
          is_verified_purchase: boolean;
          created_at: string;
          updated_at: string;
        };
      };
      user_credits: {
        Row: {
          id: string;
          user_id: string;
          balance: number;
          lifetime_earned: number;
          created_at: string;
          updated_at: string;
        };
      };
      credit_transactions: {
        Row: {
          id: string;
          user_id: string;
          order_id: string | null;
          amount: number;
          type: string;
          description: string;
          created_at: string;
        };
      };
      support_tickets: {
        Row: {
          id: string;
          user_id: string;
          subject: string;
          message: string;
          status: string;
          priority: string;
          created_at: string;
          updated_at: string;
        };
      };
      laptop_models: {
        Row: {
          id: string;
          brand: string;
          model_name: string;
          model_number: string;
          compatible_parts: any;
          specifications: any;
          created_at: string;
        };
      };
    };
  };
}
