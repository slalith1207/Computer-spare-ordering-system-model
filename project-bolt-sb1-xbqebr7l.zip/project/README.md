# TechParts Pro - Computer Spare Parts E-commerce Platform

A comprehensive e-commerce platform for ordering computer spare parts with advanced features including AI-powered search, rewards system, and 24/7 support.

## Features

### 1. User Authentication
- Email and password authentication
- Secure user registration and login
- Profile management

### 2. Product Catalog
- Browse computer spare parts by category and brand
- Advanced search and filtering
- Detailed product pages with specifications
- Product images and descriptions

### 3. Shopping Cart
- Add products to cart
- Update quantities
- View cart total and available credits
- Persistent cart across sessions

### 4. Checkout & Payment
- Multiple payment options:
  - UPI Payment
  - Bank Transfer
  - Cash on Delivery (COD)
- Apply reward credits to orders
- Save multiple shipping addresses

### 5. Order Management
- View all orders with status tracking
- Track order status: Pending → Processing → Shipped → Delivered
- View order details and tracking numbers
- Order history

### 6. Credits/Rewards System
- Earn 2% credits on every purchase
- Use credits to reduce order total
- View credit balance and lifetime earnings
- Transaction history

### 7. Review System
- Rate products (1-5 stars)
- Write detailed reviews
- Upload images/videos (coming soon)
- Verified purchase badges
- View all product reviews

### 8. AI Search Assistant
- Search by laptop model name or number
- Find compatible parts for specific laptop models
- View laptop specifications
- Smart product recommendations

### 9. 24/7 Help Center
- Create support tickets
- Live chat interface
- Priority system (Low, Medium, High)
- Ticket status tracking
- Message history

### 10. User Profile
- Update personal information
- Manage multiple addresses
- View credit balance
- Account customization

## Technology Stack

- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Icons**: Lucide React

## Database Schema

The platform uses a comprehensive database schema with:
- User profiles and authentication
- Products, categories, and brands
- Shopping cart and orders
- Reviews and ratings
- Credits and transactions
- Support tickets
- Laptop models for compatibility

## Security Features

- Row Level Security (RLS) on all tables
- Secure authentication flow
- Protected user data
- Verified purchase reviews

## Getting Started

1. Create an account or sign in
2. Browse products by category or use the AI search
3. Add items to your cart
4. Proceed to checkout and complete your order
5. Track your order and earn credits
6. Leave reviews for purchased products

## Payment Methods

- **UPI**: Instant payment via UPI apps
- **Bank Transfer**: Direct bank account transfer
- **Cash on Delivery**: Pay when you receive the order

## Credits System

- Earn 2% of order value as credits
- Credits can be used on future purchases
- No expiry on credits
- Track all credit transactions

## Support

Use the 24/7 Help Center to:
- Get product assistance
- Track orders
- Report issues
- Ask questions

## Sample Data

The platform comes pre-loaded with:
- 10+ product categories
- 14+ popular brands
- Sample products across all categories
- Laptop models for compatibility search
